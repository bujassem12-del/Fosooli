// فصولي — زر «استيراد إلى فصولي» داخل نظام نور.
// يقرأ أسماء الطلاب وأرقام هوياتهم من أي جدول طلاب بالصفحة (قائمة الطلاب،
// إدخال الدرجات...)، ويجمع كل الصفحات لو الجدول مقسّم، ثم يرسلها لفصولي.
// ما يرسل أي شيء لأي مكان غير تبويب فصولي بنفس المتصفح.
(function () {
  if (window.top !== window) return; // نشتغل بالصفحة الرئيسية فقط
  const STATE_KEY = "fosooli-collect";
  const JUNK = ["الاسم الرباعي", "رقم الهوية", "اسم الطالب", "الطالب", "خيارات", "ملاحظات", "عرض", "إضافة", "الطلاب", "تحديد الكل", "حاضر", "غائب", "غاش", "صفر"];

  const clean = (t) => String(t || "").replace(/\s+/g, " ").trim();
  const asId = (t) => { const d = clean(t).replace(/[^\d]/g, ""); return /^\d{10}$/.test(d) && clean(t).replace(/[\s\-]/g, "").length <= 12 ? d : null; };
  const isName = (t) => {
    const s = clean(t);
    return s.length >= 5 && s.length <= 90 && /\s/.test(s) && !/\d/.test(s) && /[؀-ۿ]/.test(s) && !JUNK.includes(s);
  };

  // ===== قراءة الطلاب من الصفحة =====
  function scan() {
    const out = [];
    const seen = new Set();
    document.querySelectorAll("tr").forEach((tr) => {
      const cells = Array.from(tr.children).filter((c) => c.tagName === "TD" || c.tagName === "TH");
      if (cells.length < 2) return;
      let id = null, name = null;
      for (const c of cells) {
        const txt = clean(c.innerText || c.textContent);
        if (!id && asId(txt)) { id = asId(txt); continue; }
        if (!name && isName(txt)) name = txt;
        if (id && name) break;
      }
      if (!name) return;
      // لو ما فيه هوية، نقبل الصف بس إذا الجدول عنوانه فيه "الطالب"/"الاسم"
      if (!id) {
        const table = tr.closest("table");
        const head = table ? clean((table.querySelector("th") || {}).innerText || table.rows[0]?.innerText || "") : "";
        if (!/الطالب|الاسم/.test(head)) return;
      }
      const key = id || name;
      if (seen.has(key)) return;
      seen.add(key);
      out.push({ name, nationalId: id || "" });
    });
    return out;
  }

  function totalRecords() {
    const m = document.body.innerText.match(/عدد السجلات(?: الكلي)?\s*[:：]?\s*(\d+)/);
    return m ? Number(m[1]) : null;
  }

  // روابط ترقيم صفحات ASP.NET (Page$2 ...)
  function pager() {
    const links = Array.from(document.querySelectorAll("a[href*='Page$']"));
    if (!links.length) return null;
    const pagerRow = links[0].closest("tr");
    const current = pagerRow ? Array.from(pagerRow.querySelectorAll("span")).map((s) => Number(clean(s.innerText))).find((n) => n > 0) : null;
    const pages = links.map((a) => ({ a, n: Number(clean(a.innerText)) })).filter((x) => x.n > 0);
    const cur = current || 1;
    const next = pages.find((p) => p.n === cur + 1) || null;
    const more = links.find((a) => clean(a.innerText) === "..." && /Page\$/.test(a.getAttribute("href") || ""));
    return { cur, next: next ? next.a : (more || null), hasPages: pages.length > 0 };
  }

  // ===== الواجهة (Shadow DOM عشان ما تتأثر بتنسيق نور) =====
  const host = document.createElement("div");
  host.id = "fosooli-import-host";
  host.style.cssText = "position:fixed;left:20px;bottom:20px;z-index:2147483646;";
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; font-family: "IBM Plex Sans Arabic", Tahoma, Arial, sans-serif; }
      .wrap { direction: rtl; display: flex; flex-direction: column; align-items: flex-start; gap: 10px; }
      .btn { display: inline-flex; align-items: center; gap: 10px; height: 52px; padding: 0 18px 0 14px; border: 0; border-radius: 16px;
             background: #1565C0; color: #fff; font-size: 15px; font-weight: 700; cursor: pointer;
             box-shadow: 0 10px 28px rgba(21,101,192,.38), 0 2px 6px rgba(0,0,0,.12); transition: transform .15s, filter .15s; }
      .btn:hover { filter: brightness(1.06); transform: translateY(-1px); }
      .btn:active { transform: scale(.97); }
      .btn[disabled] { opacity: .65; cursor: default; transform: none; }
      .logo { width: 30px; height: 30px; border-radius: 9px; background: rgba(255,255,255,.18); display: flex; align-items: center; justify-content: center; }
      .count { background: #fff; color: #1565C0; border-radius: 999px; font-size: 12px; padding: 2px 9px; font-weight: 800; }
      .card { width: 320px; background: #fff; color: #16201E; border-radius: 18px; padding: 16px; box-shadow: 0 20px 50px rgba(0,0,0,.22); border: 1px solid #E1E6E4; }
      .card h3 { margin: 0 0 6px; font-size: 16px; }
      .card p { margin: 0 0 12px; font-size: 13px; color: #56625F; line-height: 1.6; }
      .row { display: flex; gap: 8px; }
      .act { flex: 1; height: 42px; border-radius: 12px; border: 1px solid #E1E6E4; background: #fff; color: #16201E; font-weight: 700; font-size: 13px; cursor: pointer; }
      .act.primary { background: #1565C0; border-color: #1565C0; color: #fff; }
      .x { float: left; border: 0; background: transparent; font-size: 18px; color: #56625F; cursor: pointer; line-height: 1; }
      .ok { color: #0F6B5C; }
      .err { color: #B42318; }
      .bar { height: 6px; background: #EEF2F1; border-radius: 99px; overflow: hidden; margin: 4px 0 12px; }
      .bar > i { display: block; height: 100%; background: #1565C0; width: 0; transition: width .3s; }
    </style>
    <div class="wrap">
      <div class="card" id="card" hidden></div>
      <button class="btn" id="btn" type="button" aria-label="استيراد أسماء الطلاب إلى فصولي">
        <span class="logo"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="4.2" rx="2.1" fill="#fff"/><rect x="3" y="10" width="12" height="4.2" rx="2.1" fill="#fff" fill-opacity=".8"/><rect x="3" y="16" width="15" height="4.2" rx="2.1" fill="#fff" fill-opacity=".6"/><circle cx="19.2" cy="12.1" r="2.1" fill="#fff"/></svg></span>
        <span>استيراد إلى فصولي</span>
        <span class="count" id="count" hidden>0</span>
      </button>
    </div>`;
  const $ = (id) => root.getElementById(id);
  const btn = $("btn"), countEl = $("count"), card = $("card");

  function showCard(html) { card.innerHTML = `<button class="x" type="button" aria-label="إغلاق">×</button>${html}`; card.hidden = false; card.querySelector(".x").onclick = () => { card.hidden = true; }; }
  function refreshCount() {
    const n = scan().length;
    countEl.textContent = String(n);
    countEl.hidden = n === 0;
  }

  function send(students, meta) {
    btn.disabled = true;
    showCard(`<h3>جاري الإرسال لفصولي…</h3><p>${students.length} طالب</p>`);
    try {
      chrome.runtime.sendMessage({ type: "noor-students", students, meta }, (res) => {
        btn.disabled = false;
        if (chrome.runtime.lastError || !res || !res.ok) {
          showCard(`<h3 class="err">ما قدرنا نرسل</h3><p>تأكد إن إضافة فصولي مفعّلة، وحدّث الصفحة وحاول مرة ثانية.</p>`);
          return;
        }
        showCard(`<h3 class="ok">✓ تم إرسال ${students.length} طالب لفصولي</h3><p>${res.opened ? "فتحنا لك فصولي بتبويب جديد." : "انتقلنا لتبويب فصولي."} راجع الأسماء هناك واضغط «استيراد».</p>`);
      });
    } catch (e) {
      btn.disabled = false;
      showCard(`<h3 class="err">انقطع اتصال الإضافة</h3><p>حدّث صفحة نور (F5) وحاول مرة ثانية.</p>`);
    }
  }

  // ===== جمع كل الصفحات =====
  // نور أحيانًا يغيّر الصفحة بدون إعادة تحميل (تحديث جزئي) وأحيانًا يعيد التحميل
  // بالكامل؛ نحفظ التقدّم بـ sessionStorage عشان نكمل بالحالتين.
  const keyOf = (s) => s.nationalId || s.name;
  const readState = () => { try { return JSON.parse(sessionStorage.getItem(STATE_KEY) || "null"); } catch (e) { return null; } };
  const saveState = (st) => sessionStorage.setItem(STATE_KEY, JSON.stringify(st));
  function merge(st) {
    const seen = new Set(st.students.map(keyOf));
    scan().forEach((s) => { const k = keyOf(s); if (!seen.has(k)) { seen.add(k); st.students.push(s); } });
    saveState(st);
    const pct = st.total ? Math.min(100, Math.round((st.students.length / st.total) * 100)) : 50;
    showCard(`<h3>جاري جمع كل الصفحات…</h3><div class="bar"><i style="width:${pct}%"></i></div><p>${st.students.length}${st.total ? ` من ${st.total}` : ""} طالب</p>`);
    return st;
  }
  function startCollectAll() {
    const st = merge({ students: [], total: totalRecords(), started: Date.now(), visited: [] });
    step(st);
  }
  function step(st) {
    if (st.total && st.students.length >= st.total) { finishCollect(); return; }
    const p = pager();
    if (!p || !p.next) { finishCollect(); return; }
    const before = (scan()[0] && keyOf(scan()[0])) || "";
    st.visited = [...(st.visited || []), p.cur];
    saveState(st);
    p.next.click();
    // لو الصفحة تغيّرت بدون إعادة تحميل: ننتظر تغيّر أول صف ثم نكمل
    let tries = 0;
    const poll = setInterval(() => {
      tries += 1;
      const first = scan()[0];
      const now = (first && keyOf(first)) || "";
      if (now && now !== before) { clearInterval(poll); step(merge(readState() || st)); }
      else if (tries > 40) { clearInterval(poll); finishCollect(); }
    }, 400);
  }
  function finishCollect() {
    const st = readState();
    sessionStorage.removeItem(STATE_KEY);
    if (!st) return;
    send(st.students, { page: location.pathname, total: st.total });
  }
  // بعد إعادة تحميل كاملة للصفحة التالية
  function resumeIfCollecting() {
    const st = readState();
    if (!st) return false;
    if (Date.now() - st.started > 3 * 60 * 1000) { sessionStorage.removeItem(STATE_KEY); return false; }
    setTimeout(() => step(merge(st)), 600);
    return true;
  }

  btn.addEventListener("click", () => {
    const students = scan();
    if (!students.length) {
      showCard(`<h3>ما لقيت طلاب بهذه الصفحة</h3><p>افتح صفحة فيها جدول الطلاب، مثل: الطلاب ← الطلاب حسب العلاقات التدريسية ← «عرض» ← «الطلاب»، أو صفحة إدخال الدرجات بعد اختيار الفصل والمادة.</p>`);
      return;
    }
    const total = totalRecords();
    const p = pager();
    if (p && p.next && (!total || total > students.length)) {
      showCard(`<h3>لقيت ${students.length} طالب بهذه الصفحة</h3><p>${total ? `الجدول فيه ${total} طالب موزعين على أكثر من صفحة.` : "الجدول مقسّم على أكثر من صفحة."} تبي أجمعهم كلهم؟</p>
        <div class="row"><button class="act primary" id="all" type="button">كل الصفحات</button><button class="act" id="one" type="button">هذه الصفحة فقط</button></div>`);
      root.getElementById("all").onclick = startCollectAll;
      root.getElementById("one").onclick = () => send(students, { page: location.pathname, total });
      return;
    }
    send(students, { page: location.pathname, total });
  });

  function mount() {
    if (!document.body || document.getElementById("fosooli-import-host")) return;
    document.body.appendChild(host);
    refreshCount();
    resumeIfCollecting();
    // نور يحدّث أجزاء من الصفحة بدون إعادة تحميل → نحدّث العدد
    let t;
    new MutationObserver(() => { clearTimeout(t); t = setTimeout(refreshCount, 400); }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
