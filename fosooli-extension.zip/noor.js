// فصولي — أزرار داخل نظام نور:
//  • الأزرق «استيراد إلى فصولي»: يقرأ أسماء الطلاب وأرقام هوياتهم من جدول
//    الطلاب (كل الصفحات) ويرسلها لفصولي.
//  • الأخضر «رصد من فصولي»: بصفحة إدخال الدرجات، يعبّي خانات الدرجة من
//    الدرجات اللي جهّزتها بفصولي، حسب رقم الهوية. الحفظ تضغطه أنت بنفسك.
// ما يرسل أي شيء لأي مكان غير تبويب فصولي بنفس المتصفح.
(function () {
  if (window.top !== window) return;
  const STATE_KEY = "fosooli-collect";
  const JUNK = ["الاسم الرباعي", "رقم الهوية", "اسم الطالب", "الطالب", "خيارات", "ملاحظات", "عرض", "إضافة", "الطلاب", "تحديد الكل", "حاضر", "غائب", "غاش", "صفر"];
  const AR = /[؀-ۿ]/;

  const clean = (t) => String(t || "").replace(/[‎‏‪-‮]/g, "").replace(/\s+/g, " ").trim();
  const asId = (t) => { const c = clean(t); const d = c.replace(/[^\d]/g, ""); return /^\d{10}$/.test(d) && c.replace(/[\s\-]/g, "").length <= 12 ? d : null; };
  const isName = (t) => { const s = clean(t); return s.length >= 5 && s.length <= 90 && /\s/.test(s) && !/\d/.test(s) && AR.test(s) && !JUNK.includes(s); };
  const normName = (t) => clean(t).replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/\s+بن\s+/g, " ").replace(/\s+/g, " ");
  const cellText = (c) => clean(c.innerText || c.textContent);
  const directCells = (tr) => Array.from(tr.children).filter((c) => c.tagName === "TD" || c.tagName === "TH");

  // ===== صفوف الطلاب بالصفحة =====
  function studentRows() {
    const out = [];
    const seen = new Set();
    document.querySelectorAll("tr").forEach((tr) => {
      const cells = directCells(tr);
      if (cells.length < 2) return;
      let id = null, name = null;
      for (const c of cells) {
        const txt = cellText(c);
        if (!id && asId(txt)) { id = asId(txt); continue; }
        if (!name && isName(txt)) name = txt;
        if (id && name) break;
      }
      if (!name) return;
      if (!id) {
        const table = tr.closest("table");
        const head = table ? clean((table.querySelector("th") || {}).innerText || (table.rows[0] && table.rows[0].innerText) || "") : "";
        if (!/الطالب|الاسم/.test(head)) return;
      }
      const key = id || name;
      if (seen.has(key)) return;
      seen.add(key);
      out.push({ tr, name, nationalId: id || "" });
    });
    return out;
  }
  const scan = () => studentRows().map(({ name, nationalId }) => ({ name, nationalId }));

  function totalRecords() {
    const m = (document.body.innerText || "").match(/عدد السجلات(?:\s*الكلي)?\s*[:：]?\s*(\d+)/);
    return m ? Number(m[1]) : null;
  }

  // ===== ترقيم الصفحات (ASP.NET) =====
  function pageLinks() {
    const all = Array.from(document.querySelectorAll("a"));
    let links = all.filter((a) => /Page\$/.test(a.getAttribute("href") || "") || /Page\$/.test(a.getAttribute("onclick") || ""));
    if (!links.length) links = all.filter((a) => /^\d{1,3}$/.test(cellText(a)) && /doPostBack/i.test((a.getAttribute("href") || "") + (a.getAttribute("onclick") || "")));
    return links;
  }
  function pager() {
    const links = pageLinks();
    if (!links.length) return null;
    const box = links[0].closest("tr") || links[0].parentElement;
    let cur = null;
    if (box) {
      const marks = Array.from(box.querySelectorAll("span, b, strong, font, td")).filter((el) => !el.closest("a") && !el.querySelector("a") && /^\d{1,3}$/.test(cellText(el)));
      if (marks.length) cur = Number(cellText(marks[0]));
    }
    cur = cur || 1;
    const nums = links.map((a) => ({ a, n: Number(cellText(a)) })).filter((x) => x.n > 0);
    let next = (nums.find((x) => x.n === cur + 1) || {}).a || null;
    if (!next) {
      const dots = links.filter((a) => /^(\.\.\.|…|التالي|»|›|>)$/.test(cellText(a)));
      const maxN = Math.max(0, ...nums.map((x) => x.n));
      if (dots.length && cur >= maxN) next = dots[dots.length - 1];
    }
    return { cur, next, count: nums.length + 1 };
  }
  // ننفّذ رابط الصفحة التالية داخل الصفحة نفسها (روابط javascript: ما تنضغط من الإضافة مباشرة)
  function follow(a) {
    const raw = (a.getAttribute("href") || "") + " " + (a.getAttribute("onclick") || "");
    const m = raw.match(/__doPostBack\(\s*['"]([^'"]+)['"]\s*,\s*['"]([^'"]*)['"]\s*\)/);
    if (m) { chrome.runtime.sendMessage({ type: "postback", target: m[1], arg: m[2] }); return; }
    a.click();
  }

  // ===== الواجهة =====
  const host = document.createElement("div");
  host.id = "fosooli-import-host";
  host.style.cssText = "position:fixed;left:20px;bottom:20px;z-index:2147483646;";
  const root = host.attachShadow({ mode: "open" });
  const LOGO = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="4.2" rx="2.1" fill="#fff"/><rect x="3" y="10" width="12" height="4.2" rx="2.1" fill="#fff" fill-opacity=".8"/><rect x="3" y="16" width="15" height="4.2" rx="2.1" fill="#fff" fill-opacity=".6"/><circle cx="19.2" cy="12.1" r="2.1" fill="#fff"/></svg>';
  root.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; font-family: "IBM Plex Sans Arabic", Tahoma, Arial, sans-serif; }
      .wrap { direction: rtl; display: flex; flex-direction: column; align-items: flex-start; gap: 10px; }
      .btns { display: flex; flex-direction: column; align-items: flex-start; gap: 8px; }
      .btn { display: inline-flex; align-items: center; gap: 10px; height: 50px; padding: 0 16px 0 12px; border: 0; border-radius: 16px; color: #fff; font-size: 15px; font-weight: 700; cursor: pointer; transition: transform .15s, filter .15s; }
      .btn:hover { filter: brightness(1.06); transform: translateY(-1px); }
      .btn:active { transform: scale(.97); }
      .btn[disabled] { opacity: .65; cursor: default; transform: none; }
      .blue { background: #1565C0; box-shadow: 0 10px 28px rgba(21,101,192,.36), 0 2px 6px rgba(0,0,0,.12); }
      .green { background: #0F8A5F; box-shadow: 0 10px 28px rgba(15,138,95,.36), 0 2px 6px rgba(0,0,0,.12); }
      .logo { width: 30px; height: 30px; border-radius: 9px; background: rgba(255,255,255,.18); display: flex; align-items: center; justify-content: center; }
      .count { background: #fff; border-radius: 999px; font-size: 12px; padding: 2px 9px; font-weight: 800; }
      .blue .count { color: #1565C0; } .green .count { color: #0F8A5F; }
      .card { width: 340px; max-height: 70vh; overflow: auto; background: #fff; color: #16201E; border-radius: 18px; padding: 16px; box-shadow: 0 20px 50px rgba(0,0,0,.22); border: 1px solid #E1E6E4; }
      .card h3 { margin: 0 0 6px; font-size: 16px; }
      .card p { margin: 0 0 10px; font-size: 13px; color: #56625F; line-height: 1.7; }
      .row { display: flex; gap: 8px; margin-top: 4px; }
      .act { flex: 1; height: 42px; border-radius: 12px; border: 1px solid #E1E6E4; background: #fff; color: #16201E; font-weight: 700; font-size: 13px; cursor: pointer; }
      .act.primary { background: #1565C0; border-color: #1565C0; color: #fff; }
      .act.go { background: #0F8A5F; border-color: #0F8A5F; color: #fff; }
      select { width: 100%; height: 40px; border: 1px solid #E1E6E4; border-radius: 10px; padding: 0 10px; font-size: 13px; margin-bottom: 10px; background: #fff; }
      .x { float: left; border: 0; background: transparent; font-size: 18px; color: #56625F; cursor: pointer; line-height: 1; }
      .ok { color: #0F6B5C; } .err { color: #B42318; }
      .bar { height: 6px; background: #EEF2F1; border-radius: 99px; overflow: hidden; margin: 4px 0 12px; }
      .bar > i { display: block; height: 100%; background: #1565C0; width: 0; transition: width .3s; }
      ul { margin: 0 0 10px; padding: 0 18px 0 0; font-size: 12px; color: #B42318; line-height: 1.8; }
    </style>
    <div class="wrap">
      <div class="card" id="card" hidden></div>
      <div class="btns">
        <button class="btn green" id="grade" type="button" hidden aria-label="رصد الدرجات من فصولي">
          <span class="logo">${LOGO}</span><span>رصد من فصولي</span><span class="count" id="gcount" hidden>0</span>
        </button>
        <button class="btn blue" id="btn" type="button" aria-label="استيراد أسماء الطلاب إلى فصولي">
          <span class="logo">${LOGO}</span><span>استيراد إلى فصولي</span><span class="count" id="count" hidden>0</span>
        </button>
      </div>
    </div>`;
  const $ = (id) => root.getElementById(id);
  const btn = $("btn"), countEl = $("count"), card = $("card"), gradeBtn = $("grade"), gcount = $("gcount");
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  function showCard(html) { card.innerHTML = `<button class="x" type="button" aria-label="إغلاق">×</button>${html}`; card.hidden = false; card.querySelector(".x").onclick = () => { card.hidden = true; }; }

  // ===================================================== الاستيراد
  function send(students, meta) {
    btn.disabled = true;
    showCard(`<h3>جاري الإرسال لفصولي…</h3><p>${students.length} طالب</p>`);
    try {
      chrome.runtime.sendMessage({ type: "noor-students", students, meta }, (res) => {
        btn.disabled = false;
        if (chrome.runtime.lastError || !res || !res.ok) { showCard(`<h3 class="err">ما قدرنا نرسل</h3><p>حدّث الصفحة (F5) وحاول مرة ثانية.</p>`); return; }
        const total = meta && meta.total;
        const warn = total && students.length < total ? `<p class="err">تنبيه: الجدول فيه ${total} طالب ووصل ${students.length} بس. جرّب مرة ثانية، أو افتح كل صفحة واضغط الزر.</p>` : "";
        showCard(`<h3 class="ok">✓ تم إرسال ${students.length} طالب لفصولي</h3>${warn}<p>${res.opened ? "فتحنا لك فصولي بتبويب جديد." : "انتقلنا لتبويب فصولي."} راجع الأسماء هناك واضغط «استيراد».</p>`);
      });
    } catch (e) {
      btn.disabled = false;
      showCard(`<h3 class="err">انقطع اتصال الإضافة</h3><p>حدّث صفحة نور (F5) وحاول مرة ثانية.</p>`);
    }
  }

  const keyOf = (s) => s.nationalId || s.name;
  const readState = () => { try { return JSON.parse(sessionStorage.getItem(STATE_KEY) || "null"); } catch (e) { return null; } };
  const saveState = (st) => sessionStorage.setItem(STATE_KEY, JSON.stringify(st));
  function merge(st) {
    const seen = new Set(st.students.map(keyOf));
    scan().forEach((s) => { const k = keyOf(s); if (!seen.has(k)) { seen.add(k); st.students.push(s); } });
    saveState(st);
    const pct = st.total ? Math.min(100, Math.round((st.students.length / st.total) * 100)) : 50;
    showCard(`<h3>جاري جمع كل الصفحات…</h3><div class="bar"><i style="width:${pct}%"></i></div><p>${st.students.length}${st.total ? ` من ${st.total}` : ""} طالب — لا تضغط شي بالصفحة</p>`);
    return st;
  }
  function startCollectAll() {
    const st = merge({ students: [], total: totalRecords(), started: Date.now(), pagesSeen: 1 });
    step(st);
  }
  function step(st) {
    if (st.total && st.students.length >= st.total) { finishCollect(); return; }
    const p = pager();
    if (!p || !p.next || st.pagesSeen > 60) { finishCollect(); return; }
    const before = scan().map(keyOf).join("|");
    st.pagesSeen += 1;
    saveState(st);
    follow(p.next);
    let tries = 0;
    const poll = setInterval(() => {
      tries += 1;
      const now = scan().map(keyOf).join("|");
      if (now && now !== before) { clearInterval(poll); setTimeout(() => step(merge(readState() || st)), 250); }
      else if (tries > 50) { clearInterval(poll); finishCollect(); }
    }, 400);
  }
  function finishCollect() {
    const st = readState();
    sessionStorage.removeItem(STATE_KEY);
    if (!st) return;
    send(st.students, { page: location.pathname, total: st.total });
  }
  function resumeIfCollecting() {
    const st = readState();
    if (!st) return;
    if (Date.now() - st.started > 4 * 60 * 1000) { sessionStorage.removeItem(STATE_KEY); return; }
    setTimeout(() => step(merge(st)), 700);
  }

  btn.addEventListener("click", () => {
    const students = scan();
    if (!students.length) {
      showCard(`<h3>ما لقيت طلاب بهذه الصفحة</h3><p>افتح صفحة فيها جدول الطلاب، مثل: الطلاب ← الطلاب حسب العلاقات التدريسية ← «عرض» ← «الطلاب»، أو صفحة إدخال الدرجات بعد اختيار الفصل والمادة.</p>`);
      return;
    }
    const total = totalRecords();
    const p = pager();
    const more = (total && total > students.length) || (p && p.next);
    if (more && p && p.next) { startCollectAll(); return; } // نجمع كل الصفحات تلقائيًا
    send(students, { page: location.pathname, total });
  });

  // ===================================================== الرصد (الزر الأخضر)
  // أعمدة الدرجات: عناوين فيها "/ رقم" (مثل: المهام الأدائية والمشاركة والتفاعل / 40)
  function gradeColumns() {
    const rows = studentRows();
    if (!rows.length) return [];
    const table = rows[0].tr.closest("table");
    const sample = rows[0].tr;
    const inputs = Array.from(sample.querySelectorAll("input[type=text], input:not([type])")).filter((i) => !/note/i.test(i.id || i.name || ""));
    if (!inputs.length) return [];
    // نلقى صف العناوين
    let headRow = null;
    for (const r of Array.from(table.rows)) { if (r === sample) break; if (/\/\s*\d+/.test(r.innerText || "")) headRow = r; }
    const heads = headRow ? directCells(headRow).map(cellText).filter((t) => /\/\s*\d+/.test(t)) : [];
    return inputs.map((inp, i) => {
      const h = heads[i] || `عمود ${i + 1}`;
      const m = h.match(/\/\s*(\d+(?:\.\d+)?)/);
      return { index: i, label: h.replace(/\s*(--\s*)?الكل\s*--.*$/, "").replace(/حاضر.*$/, "").trim(), max: m ? Number(m[1]) : null };
    });
  }
  function gradeInputs(tr) {
    return Array.from(tr.querySelectorAll("input[type=text], input:not([type])")).filter((i) => !/note/i.test(i.id || i.name || ""));
  }
  function setVal(inp, v) {
    const proto = Object.getPrototypeOf(inp);
    const setter = Object.getOwnPropertyDescriptor(proto, "value") && Object.getOwnPropertyDescriptor(proto, "value").set;
    inp.focus();
    if (setter) setter.call(inp, v); else inp.value = v;
    ["input", "keyup", "change"].forEach((t) => inp.dispatchEvent(new Event(t, { bubbles: true })));
    inp.dispatchEvent(new Event("blur"));
    inp.style.background = "#E3F6EC";
    inp.style.outline = "2px solid #0F8A5F";
  }
  async function getGrades() {
    const { grades } = await chrome.storage.local.get("grades");
    return grades && Array.isArray(grades.students) && grades.students.length ? grades : null;
  }
  async function refreshGradeBtn() {
    const cols = gradeColumns();
    const g = await getGrades();
    gradeBtn.hidden = !cols.length;
    gcount.hidden = !g;
    if (g) gcount.textContent = String(g.students.length);
  }

  function fill(g, col) {
    const rows = studentRows();
    const byId = new Map(g.students.filter((s) => s.nationalId).map((s) => [s.nationalId, s]));
    const byName = new Map(g.students.map((s) => [normName(s.name), s]));
    const factor = col.max && g.max && Number(col.max) !== Number(g.max) ? Number(col.max) / Number(g.max) : 1;
    let filled = 0;
    const missing = [];
    rows.forEach((r) => {
      const s = (r.nationalId && byId.get(r.nationalId)) || byName.get(normName(r.name));
      const inp = gradeInputs(r.tr)[col.index];
      if (!inp) return;
      if (!s || s.score === null || s.score === undefined || s.score === "") { missing.push(r.name); inp.style.outline = "2px solid #E0A400"; return; }
      let v = Number(s.score) * factor;
      v = g.round ? Math.round(v) : Math.round(v * 100) / 100;
      if (col.max) v = Math.max(0, Math.min(Number(col.max), v));
      setVal(inp, String(v));
      filled += 1;
    });
    const p = pager();
    const scaled = factor !== 1 ? `<p>درجات فصولي من ${g.max} وعمود نور من ${col.max}، فحوّلناها بالنسبة.</p>` : "";
    const miss = missing.length ? `<p class="err">ما لقيت درجة لـ ${missing.length} طالب (معلّمين بالأصفر):</p><ul>${missing.slice(0, 12).map((n) => `<li>${esc(n)}</li>`).join("")}${missing.length > 12 ? "<li>…</li>" : ""}</ul>` : "";
    const next = p && p.next ? `<p><b>الجدول فيه صفحات ثانية:</b> احفظ هذه الصفحة أول، بعدين روح للصفحة التالية واضغط «رصد من فصولي» مرة ثانية.</p>` : "";
    showCard(`<h3 class="ok">✓ عبّيت ${filled} درجة</h3><p>العمود: ${esc(col.label)}<br>من: ${esc(g.label || "فصولي")}</p>${scaled}${miss}<p><b>راجع الدرجات (معلّمة بالأخضر) واضغط «حفظ» في نور بنفسك.</b></p>${next}`);
  }

  gradeBtn.addEventListener("click", async () => {
    const g = await getGrades();
    if (!g) {
      showCard(`<h3>ما فيه درجات جاهزة</h3><p>بفصولي: افتح الفصل ← «درجات الوحدات والنقل» ← «درجات جميع الوحدات» ← «تجهيز للرصد في نور»، وبعدها ارجع هنا واضغط الزر.</p>`);
      return;
    }
    const cols = gradeColumns();
    if (!cols.length) { showCard(`<h3>ما لقيت خانات درجات</h3><p>افتح صفحة إدخال الدرجات واختر الفصل والمادة والاختبار.</p>`); return; }
    const head = `<h3>رصد ${g.students.length} طالب</h3><p>من: ${esc(g.label || "فصولي")} — الدرجة من ${g.max}</p>`;
    if (cols.length === 1) {
      showCard(`${head}<p>العمود: ${esc(cols[0].label)}${cols[0].max ? ` (من ${cols[0].max})` : ""}</p><div class="row"><button class="act go" id="go" type="button">عبّي الدرجات</button><button class="act" id="no" type="button">إلغاء</button></div>`);
    } else {
      showCard(`${head}<p>اختر العمود:</p><select id="col">${cols.map((c) => `<option value="${c.index}">${esc(c.label)}${c.max ? ` (من ${c.max})` : ""}</option>`).join("")}</select><div class="row"><button class="act go" id="go" type="button">عبّي الدرجات</button><button class="act" id="no" type="button">إلغاء</button></div>`);
    }
    root.getElementById("no").onclick = () => { card.hidden = true; };
    root.getElementById("go").onclick = () => {
      const sel = root.getElementById("col");
      const col = cols[sel ? Number(sel.value) : 0];
      fill(g, col);
    };
  });

  // ===================================================== تشغيل
  function refreshCount() {
    const n = scan().length;
    countEl.textContent = String(n);
    countEl.hidden = n === 0;
    refreshGradeBtn();
  }
  function mount() {
    if (!document.body || document.getElementById("fosooli-import-host")) return;
    document.body.appendChild(host);
    refreshCount();
    resumeIfCollecting();
    let t;
    new MutationObserver(() => { clearTimeout(t); t = setTimeout(refreshCount, 400); }).observe(document.body, { childList: true, subtree: true });
    chrome.storage.onChanged.addListener((ch) => { if (ch.grades) refreshGradeBtn(); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
