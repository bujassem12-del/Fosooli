// فصولي — الوسيط بين تبويب نور وتبويب فصولي.
// يستقبل الأسماء من زر نور، يحفظها مؤقتًا، ويوصلها لأول تبويب فصولي مفتوح
// (أو يفتح فصولي لو ما كان مفتوح). البيانات ما تطلع من متصفحك أبدًا.
const FOSOOLI_URL = "https://fosooli.vercel.app/";
const FOSOOLI_MATCH = ["https://fosooli.vercel.app/*", "http://localhost/*"];

async function deliver(payload) {
  await chrome.storage.local.set({ pending: payload });
  const tabs = await chrome.tabs.query({ url: FOSOOLI_MATCH });
  if (tabs.length) {
    const tab = tabs[0];
    try { await chrome.tabs.sendMessage(tab.id, { type: "deliver-pending" }); } catch (e) { /* يستلمها لما يحمّل */ }
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
    return { ok: true, opened: false };
  }
  await chrome.tabs.create({ url: FOSOOLI_URL });
  return { ok: true, opened: true };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "noor-students") {
    deliver({ students: msg.students, meta: msg.meta || {}, at: Date.now() })
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true; // رد غير متزامن
  }
  if (msg?.type === "postback" && sender.tab) {
    // تنفيذ رابط صفحة نور التالية داخل الصفحة نفسها (__doPostBack)
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: "MAIN",
      func: (t, a) => { if (typeof window.__doPostBack === "function") window.__doPostBack(t, a); },
      args: [String(msg.target || ""), String(msg.arg || "")],
    }).then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
  if (msg?.type === "noor-grades") {
    chrome.storage.local.set({ grades: { ...msg.payload, at: Date.now() } }).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "received") {
    chrome.storage.local.remove("pending");
    sendResponse({ ok: true });
  }
  return false;
});

// الضغط على أيقونة الإضافة يفتح نظام نور
chrome.action.onClicked.addListener(() => chrome.tabs.create({ url: "https://noor.moe.gov.sa/" }));
