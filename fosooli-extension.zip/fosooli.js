// فصولي — يعلن لموقع فصولي إن الإضافة مثبّتة، ويسلّمه الأسماء القادمة من نور.
(function () {
  const VERSION = chrome.runtime.getManifest().version;
  const mark = () => document.documentElement && document.documentElement.setAttribute("data-fosooli-ext", VERSION);
  mark();
  document.addEventListener("DOMContentLoaded", mark);

  const announce = () => window.postMessage({ source: "fosooli-extension", type: "ready", version: VERSION }, location.origin);

  async function deliverPending() {
    const { pending } = await chrome.storage.local.get("pending");
    if (!pending || !pending.students || !pending.students.length) return;
    window.postMessage({ source: "fosooli-extension", type: "noor-students", students: pending.students, meta: pending.meta || {} }, location.origin);
  }

  // الموقع يأكد الاستلام → نمسح المؤقت
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.source !== "fosooli-app") return;
    if (e.data.type === "noor-students-received") chrome.runtime.sendMessage({ type: "received" });
    if (e.data.type === "ping") { announce(); deliverPending(); }
    if (e.data.type === "noor-grades" && e.data.payload) {
      chrome.runtime.sendMessage({ type: "noor-grades", payload: e.data.payload }, (res) => {
        window.postMessage({ source: "fosooli-extension", type: "noor-grades-saved", ok: !!(res && res.ok) }, location.origin);
      });
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "deliver-pending") deliverPending();
  });

  const start = () => { announce(); deliverPending(); };
  if (document.readyState === "complete") start();
  else window.addEventListener("load", start);
  // محاولة ثانية بعد تحميل التطبيق (React) بالكامل
  setTimeout(start, 2500);
})();
